import express from "express";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorizeAdmin } from "../middlewares/role.middleware.js";
import {
  getPageContent,
  updatePageContent,
} from "../controllers/page-content.controller.js";

const router = express.Router();

/**
 * Public read-only endpoint for page content.
 * GET /alpha/api/page-content/:page
 */
router.get("/:page", getPageContent);

/**
 * Admin-only update endpoint (no POST, no DELETE).
 * PUT /alpha/api/page-content/:page
 */
router.put("/:page", authenticate, authorizeAdmin, updatePageContent);

export default router;


