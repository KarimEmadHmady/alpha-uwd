// app.js
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import bodyParser from 'body-parser';
import session from 'express-session';
import mysqlSession from 'express-mysql-session';
import categoryRoutes from "./routes/category.routes.js";
import userRoutes from "./routes/user.routes.js";
import fundRoutes from "./routes/fund.routes.js";
import fundManagerRoutes from "./routes/fund-manager.routes.js";
import entityRoutes from "./routes/entity.routes.js";
import documentRoutes from "./routes/document.routes.js";
import errorHandler from './middlewares/error.middleware.js';
import con from './config/index.js';

const app = express();
const MySQLStore = mysqlSession(session);
const sessionStore = new MySQLStore(con.config);

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.set('trust proxy', 1);

app.use(session({
    key: 'session_cookie_name',
    secret: 'session_cookie_secret',
    store: sessionStore,
    resave: false,
    saveUninitialized: false
}));

app.use(cors());
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API Routes under /alpha
app.use('/alpha/api/categories', categoryRoutes);
app.use('/alpha/api/users', userRoutes);
app.use('/alpha/api/funds', fundRoutes);
app.use('/alpha/api/fund-managers', fundManagerRoutes);
app.use('/alpha/api/entities', entityRoutes);
app.use('/alpha/api/documents', documentRoutes);

// Ping route
app.get('/alpha/ping', (req, res) => {
  res.send('Server is running ✅');
});

// Welcome page for /alpha
app.get('/alpha', (req, res) => {
    res.send('Welcome to Alpha API');
});

// Error handler
app.use(errorHandler);

export default app;
