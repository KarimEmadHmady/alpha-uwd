
import mysql from 'mysql2';

const con = mysql.createConnection({
  host: process.env.DB_HOST || 'localhost', 
  user: process.env.DB_USER || 'uwddevlab_user',
  password: process.env.DB_PASSWORD || 'vr6CBF!kGNh3JP_5',
  database: process.env.DB_NAME || 'uwddevlab_database',
  port: process.env.DB_PORT || 3306,
  connectTimeout: 10000
});

con.connect(err => {
  if (err) {
    console.error('Error connecting to the database:', err);
    process.exit(1); 
  } else {
    console.log('Connected to the database');
  }
});

export default con; 